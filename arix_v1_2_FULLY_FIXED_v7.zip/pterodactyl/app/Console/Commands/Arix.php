<?php

namespace Pterodactyl\Console\Commands;

use Illuminate\Console\Command;
use Symfony\Component\Console\Formatter\OutputFormatterStyle;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Artisan;

class Arix extends Command
{
    protected $signature = 'arix {action?}';
    protected $description = 'Arix Theme installer for Pterodactyl Panel.';

    protected $supportedVersions = [
        '1.11.7', '1.11.6', '1.11.5', '1.11.4', '1.11.3', '1.11.2', '1.11.1', '1.11.0',
        '1.10.4', '1.10.3', '1.10.2', '1.10.1', '1.10.0',
        '1.9.2',  '1.9.1',  '1.9.0',
        '1.8.1',  '1.8.0',
        '1.7.0',
        '1.6.6',  '1.6.5',  '1.6.4',  '1.6.3',  '1.6.2',  '1.6.1',  '1.6.0',
    ];

    // ─────────────────────────────────────────────
    //  ENTRY POINT
    // ─────────────────────────────────────────────
    public function handle(): int
    {
        $this->setupStyles();
        $this->ensureKernelRegistration();

        $action = $this->argument('action');

        // No argument → interactive menu
        if ($action === null) {
            $this->showBanner();
            $this->interactiveMenu();
            return 0;
        }

        match ($action) {
            'install'   => $this->runInstall(),
            'remove'    => $this->runRemove(),
            'uninstall' => $this->runRemove(),
            default     => $this->error("Unknown action '{$action}'. Valid: install, remove"),
        };

        return 0;
    }

    // ─────────────────────────────────────────────
    //  BANNER
    // ─────────────────────────────────────────────
    private function showBanner(): void
    {
        $this->line('');
        $this->line('<title>');
        $this->line('        ░█████╗░██████╗░██╗██╗░░██╗');
        $this->line('        ██╔══██╗██╔══██╗██║╚██╗██╔╝');
        $this->line('        ███████║██████╔╝██║░╚███╔╝░');
        $this->line('        ██╔══██║██╔══██╗██║░██╔██╗░');
        $this->line('        ██║░░██║██║░░██║██║██╔╝╚██╗');
        $this->line('        ╚═╝░░╚═╝╚═╝░░╚═╝╚═╝╚═╝░░╚═╝');
        $this->line('</title>');
        $this->line('');
    }

    // ─────────────────────────────────────────────
    //  INTERACTIVE MENU (no argument)
    // ─────────────────────────────────────────────
    private function interactiveMenu(): void
    {
        $this->line('  <title>What do you want to do?</title>');
        $this->line('');

        $choice = $this->choice(
            '  Select an option',
            [
                '1' => '  [1]  Install Arix Theme',
                '0' => '  [0]  Remove Arix  (restore default Pterodactyl)',
            ],
            '1'
        );

        $this->line('');

        if (str_starts_with($choice, '  [1]')) {
            $this->runInstall();
        } else {
            $this->runRemove();
        }
    }

    // ─────────────────────────────────────────────
    //  INSTALL
    // ─────────────────────────────────────────────
    private function runInstall(): void
    {
        $this->line('');
        $this->line('  <title>━━━━━━━━  ARIX INSTALLER  ━━━━━━━━</title>');
        $this->line('');

        // ── STEP 1: System scan ──────────────────
        $this->line('  <title>[STEP 1/6]</title>  Scanning system...');
        $this->line('');

        $scanPassed = $this->runSystemScan();

        if (!$scanPassed) {
            $this->line('');
            $this->warn('  ⚠  Scan found issues. Fix them before installing.');
            if (!$this->confirm('  Continue anyway?', false)) {
                $this->info('  Installation cancelled.');
                return;
            }
        }

        // ── STEP 2: Panel version check ──────────
        $this->line('');
        $this->line('  <title>[STEP 2/6]</title>  Checking Pterodactyl version...');
        $this->line('');

        $panelVersion = config('app.version', 'unknown');
        if (in_array($panelVersion, $this->supportedVersions)) {
            $this->line("  <info>✓</info>  Panel version <b>{$panelVersion}</b> — Supported");
        } else {
            $this->line("  <comment>⚠</comment>  Panel version <b>{$panelVersion}</b> — Not in tested list");
            $this->line("  <comment>   Tested on:</comment> " . implode(', ', $this->supportedVersions));
            if (!$this->confirm('  Continue anyway?', true)) {
                $this->info('  Installation cancelled.');
                return;
            }
        }

        // ── STEP 3: Choose version ───────────────
        $this->line('');
        $this->line('  <title>[STEP 3/6]</title>  Selecting theme version...');
        $this->line('');

        $versions = File::directories('./arix');
        if (empty($versions)) {
            $this->error('  No versions found in ./arix directory. Put theme files there first.');
            return;
        }

        $versionNames = array_map('basename', $versions);
        $rawVersion   = $this->choice('  Select version', $versionNames, 0);
        $version      = preg_replace('/[^a-zA-Z0-9._-]/', '', $rawVersion);

        if (empty($version)) {
            $this->error('  Invalid version selected.');
            return;
        }

        $this->line("  <info>✓</info>  Selected: <b>{$version}</b>");

        // ── STEP 4: Install dependencies ─────────
        $this->line('');
        $this->line('  <title>[STEP 4/6]</title>  Installing dependencies...');
        $this->line('');

        $this->installDependencies();

        // ── STEP 5: Copy files + migrate ─────────
        $this->line('');
        $this->line('  <title>[STEP 5/6]</title>  Copying theme files...');
        $this->line('');

        $this->arixExec("rsync -a arix/" . escapeshellarg($version) . "/ ./");

        $directoryPath = app_path('Http/Controllers/Admin/Arix');
        File::makeDirectory($directoryPath, 0755, true, true);

        $this->line("  <info>✓</info>  Files copied");
        $this->line('');
        $this->line('  Running database migrations...');
        $this->arixExec('php artisan migrate --force');
        $this->line("  <info>✓</info>  Database migrated");

        // ── STEP 6: Build + permissions ──────────
        $this->line('');
        $this->line('  <title>[STEP 6/6]</title>  Building assets & setting permissions...');
        $this->line('');

        $this->buildAssets();
        $this->setPermissions();
        $this->optimizeApp();

        // ── Done ─────────────────────────────────
        $this->line('');
        $this->line('  <title>╭─────────────────────────────────────╮</title>');
        $this->line('  <title>│                                     │</title>');
        $this->line('  <title>│      ✓  Arix installed successfully  │</title>');
        $this->line('  <title>│                                     │</title>');
        $this->line('  <title>╰─────────────────────────────────────╯</title>');
        $this->line('');
        $this->line('  Open your panel admin area → <b>/admin/arix</b> to configure the theme.');
        $this->line('');
    }

    // ─────────────────────────────────────────────
    //  REMOVE / UNINSTALL
    // ─────────────────────────────────────────────
    private function runRemove(): void
    {
        $this->line('');
        $this->line('  <title>━━━━━━━━  ARIX REMOVER  ━━━━━━━━</title>');
        $this->line('');
        $this->warn('  ⚠  This will remove Arix and restore the default Pterodactyl panel.');
        $this->warn('  ⚠  All your Arix customizations will be lost.');
        $this->line('');

        if (!$this->confirm('  Are you sure you want to remove Arix?', false)) {
            $this->info('  Removal cancelled.');
            return;
        }

        $this->line('');
        $this->line('  Putting panel into maintenance mode...');
        $this->arixExec('php artisan down');

        $this->line('  Downloading default Pterodactyl panel...');
        $this->arixExec('curl -fsSL https://github.com/pterodactyl/panel/releases/latest/download/panel.tar.gz | tar -xzv');

        $this->line('  Setting permissions...');
        $this->arixExec('chmod -R 755 storage/* bootstrap/cache');

        $this->line('  Installing composer packages...');
        $this->arixExec('composer install --no-dev --optimize-autoloader');

        $this->line('  Clearing caches...');
        $this->arixExec('php artisan view:clear');
        $this->arixExec('php artisan config:clear');

        $this->line('  Running migrations...');
        $this->arixExec('php artisan migrate --seed --force');

        $this->setPermissions();

        $this->line('  Restarting queue & bringing panel back online...');
        $this->arixExec('php artisan queue:restart');
        $this->arixExec('php artisan up');

        $this->line('');
        $this->line('  <title>╭─────────────────────────────────────╮</title>');
        $this->line('  <title>│                                     │</title>');
        $this->line('  <title>│     ✓  Arix removed successfully     │</title>');
        $this->line('  <title>│      Panel restored to default.      │</title>');
        $this->line('  <title>│                                     │</title>');
        $this->line('  <title>╰─────────────────────────────────────╯</title>');
        $this->line('');
    }

    // ─────────────────────────────────────────────
    //  SYSTEM SCAN
    // ─────────────────────────────────────────────
    private function runSystemScan(): bool
    {
        $allGood = true;

        // ── OS / Distro ──────────────────────────
        $os = trim((string) shell_exec('cat /etc/os-release 2>/dev/null | grep PRETTY_NAME | cut -d= -f2 | tr -d \'"\''));
        if ($os) {
            $this->line("  <info>✓</info>  OS: <b>{$os}</b>");
        } else {
            $this->line("  <comment>?</comment>  OS: Could not detect");
        }

        // ── VPS / Virtualization ─────────────────
        $virt = trim((string) shell_exec('systemd-detect-virt 2>/dev/null || cat /proc/cpuinfo | grep hypervisor 2>/dev/null | head -1'));
        if ($virt && $virt !== 'none') {
            $this->line("  <info>✓</info>  Virtualization: <b>{$virt}</b>");
        } else {
            $this->line("  <info>✓</info>  Virtualization: Bare-metal / Unknown");
        }

        // ── PHP ──────────────────────────────────
        $phpVersion = PHP_VERSION;
        $phpMajor   = (int) PHP_MAJOR_VERSION;
        $phpMinor   = (int) PHP_MINOR_VERSION;
        if ($phpMajor >= 8) {
            $this->line("  <info>✓</info>  PHP: <b>{$phpVersion}</b> — OK (8.0+ required)");
        } else {
            $this->line("  <error>✗</error>  PHP: <b>{$phpVersion}</b> — FAILED (8.0+ required)");
            $allGood = false;
        }

        // ── Node.js ──────────────────────────────
        $nodeRaw     = trim((string) shell_exec('node -v 2>/dev/null'));
        $nodeVersion = (int) ltrim($nodeRaw, 'v');
        if ($nodeVersion >= 16) {
            $label = $nodeVersion >= 17 ? "OK (will use --openssl-legacy-provider)" : "OK";
            $this->line("  <info>✓</info>  Node.js: <b>{$nodeRaw}</b> — {$label}");
        } elseif ($nodeVersion > 0) {
            $this->line("  <error>✗</error>  Node.js: <b>{$nodeRaw}</b> — FAILED (16+ required)");
            $allGood = false;
        } else {
            $this->line("  <error>✗</error>  Node.js: Not found — FAILED");
            $allGood = false;
        }

        // ── Yarn ─────────────────────────────────
        $yarnRaw = trim((string) shell_exec('yarn --version 2>/dev/null'));
        if ($yarnRaw) {
            $this->line("  <info>✓</info>  Yarn: <b>{$yarnRaw}</b> — OK");
        } else {
            $this->line("  <error>✗</error>  Yarn: Not found — FAILED (run: npm install -g yarn)");
            $allGood = false;
        }

        // ── Composer ─────────────────────────────
        $composerRaw = trim((string) shell_exec('composer --version 2>/dev/null | head -1'));
        if ($composerRaw) {
            $this->line("  <info>✓</info>  Composer: <b>{$composerRaw}</b> — OK");
        } else {
            $this->line("  <error>✗</error>  Composer: Not found — FAILED");
            $allGood = false;
        }

        // ── rsync ────────────────────────────────
        $rsync = trim((string) shell_exec('which rsync 2>/dev/null'));
        if ($rsync) {
            $this->line("  <info>✓</info>  rsync: <b>{$rsync}</b> — OK");
        } else {
            $this->line("  <error>✗</error>  rsync: Not found — FAILED (run: apt install rsync)");
            $allGood = false;
        }

        // ── curl ─────────────────────────────────
        $curl = trim((string) shell_exec('curl --version 2>/dev/null | head -1'));
        if ($curl) {
            $this->line("  <info>✓</info>  curl: OK");
        } else {
            $this->line("  <error>✗</error>  curl: Not found — FAILED");
            $allGood = false;
        }

        // ── Disk space ───────────────────────────
        $freeKb = (int) shell_exec("df --output=avail " . escapeshellarg(base_path()) . " 2>/dev/null | tail -1");
        $freeMb = (int) ($freeKb / 1024);
        if ($freeMb >= 500) {
            $this->line("  <info>✓</info>  Disk space: <b>{$freeMb} MB</b> free — OK");
        } else {
            $this->line("  <error>✗</error>  Disk space: <b>{$freeMb} MB</b> free — LOW (500 MB+ recommended)");
            $allGood = false;
        }

        // ── Web server ───────────────────────────
        $webserver = 'Unknown';
        if (trim((string) shell_exec('which nginx 2>/dev/null'))) {
            $webserver = 'nginx (' . trim((string) shell_exec('nginx -v 2>&1 | head -1')) . ')';
        } elseif (trim((string) shell_exec('which apache2 2>/dev/null')) || trim((string) shell_exec('which httpd 2>/dev/null'))) {
            $webserver = 'Apache';
        }
        $this->line("  <info>✓</info>  Web server: <b>{$webserver}</b>");

        // ── storage/ writable ────────────────────
        $storagePath = storage_path();
        if (is_writable($storagePath)) {
            $this->line("  <info>✓</info>  storage/ directory: Writable");
        } else {
            $this->line("  <error>✗</error>  storage/ directory: NOT writable — run: chmod -R 755 storage bootstrap/cache");
            $allGood = false;
        }

        // ── ./arix folder exists ─────────────────
        $arixDir = base_path('arix');
        if (is_dir($arixDir) && !empty(File::directories($arixDir))) {
            $versions = array_map('basename', File::directories($arixDir));
            $this->line("  <info>✓</info>  ./arix theme folder: Found (" . implode(', ', $versions) . ")");
        } else {
            $this->line("  <error>✗</error>  ./arix theme folder: Not found — put Arix files in ./arix/v1.x/");
            $allGood = false;
        }

        if ($allGood) {
            $this->line('');
            $this->line("  <info>✓  All checks passed. System is ready.</info>");
        } else {
            $this->line('');
            $this->line("  <comment>⚠  Some checks failed. See above.</comment>");
        }

        return $allGood;
    }

    // ─────────────────────────────────────────────
    //  INSTALL DEPENDENCIES
    // ─────────────────────────────────────────────
    private function installDependencies(): void
    {
        $this->line('  Installing npm packages (md5, react-icons, bbcode-to-react, i18next)...');
        $this->line('  This may take 1–3 minutes...');

        $nodeVersion = (int) ltrim(trim((string) shell_exec('node -v 2>/dev/null')), 'v');
        if ($nodeVersion >= 17) {
            putenv('NODE_OPTIONS=--openssl-legacy-provider');
            $this->line("  <comment>ℹ</comment>  Node {$nodeVersion} detected — using --openssl-legacy-provider");
        }

        $this->arixExec('yarn add @types/md5 md5 react-icons @types/bbcode-to-react bbcode-to-react i18next-browser-languagedetector@7.2.1');
        $this->line("  <info>✓</info>  Packages installed");
    }

    // ─────────────────────────────────────────────
    //  BUILD ASSETS
    // ─────────────────────────────────────────────
    private function buildAssets(): void
    {
        $this->line('  Building panel assets (yarn build:production)...');
        $this->line('  This may take 2–5 minutes...');

        $nodeVersion = (int) ltrim(trim((string) shell_exec('node -v 2>/dev/null')), 'v');
        if ($nodeVersion >= 17) {
            putenv('NODE_OPTIONS=--openssl-legacy-provider');
        }

        $this->arixExec('yarn build:production');
        $this->line("  <info>✓</info>  Assets built");
    }

    // ─────────────────────────────────────────────
    //  SET PERMISSIONS
    // ─────────────────────────────────────────────
    private function setPermissions(): void
    {
        $this->line('  Setting file permissions...');
        $basePath = escapeshellarg(base_path());

        // chmod storage and cache
        $this->arixExec('chmod -R 755 storage/* bootstrap/cache');

        // chown for common web server users (errors are suppressed — not all users exist on every system)
        foreach (['www-data', 'nginx', 'apache'] as $user) {
            $check = trim((string) shell_exec("id {$user} 2>/dev/null"));
            if ($check) {
                $this->arixExec("chown -R {$user}:{$user} {$basePath}");
                $this->line("  <info>✓</info>  Permissions set for <b>{$user}</b>");
                break; // Only apply to the first found user
            }
        }
    }

    // ─────────────────────────────────────────────
    //  OPTIMIZE
    // ─────────────────────────────────────────────
    private function optimizeApp(): void
    {
        $this->line('  Optimizing application...');
        $this->arixExec('php artisan optimize:clear');
        $this->arixExec('php artisan optimize');
        $this->line("  <info>✓</info>  Application optimized");
    }

    // ─────────────────────────────────────────────
    //  KERNEL SELF-REGISTRATION
    // ─────────────────────────────────────────────
    private function ensureKernelRegistration(): void
    {
        $kernelPath = app_path('Console/Kernel.php');

        if (!File::exists($kernelPath)) {
            return;
        }

        $contents = File::get($kernelPath);
        $entry    = '\\Pterodactyl\\Console\\Commands\\Arix::class';

        if (str_contains($contents, $entry)) {
            return; // Already registered
        }

        // Insert after the opening of the $commands array
        $updated = preg_replace(
            '/(\$commands\s*=\s*\[)/',
            "$1\n        {$entry},",
            $contents,
            1
        );

        if ($updated && $updated !== $contents) {
            File::put($kernelPath, $updated);
            $this->line("  <info>✓</info>  Registered Arix command in <b>app/Console/Kernel.php</b>");
        }
    }

    // ─────────────────────────────────────────────
    //  STYLES
    // ─────────────────────────────────────────────
    private function setupStyles(): void
    {
        $title = new OutputFormatterStyle('#a78bfa', null, ['bold']);
        $this->output->getFormatter()->setStyle('title', $title);

        $b = new OutputFormatterStyle(null, null, ['bold']);
        $this->output->getFormatter()->setStyle('b', $b);
    }

    // ─────────────────────────────────────────────
    //  EXEC WRAPPER
    // ─────────────────────────────────────────────
    private function arixExec(string $cmd): void
    {
        passthru($cmd);
    }
}

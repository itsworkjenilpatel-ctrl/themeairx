<?php

namespace Pterodactyl\Http\Requests\Admin\Arix;

use Pterodactyl\Http\Requests\Admin\AdminFormRequest;

class ArixRequest extends AdminFormRequest
{
    public function rules(): array
    {
        return [
            // FIX: Was 'required|string|url' — '/arix/Arix.png' is a path not a URL, validation was failing
            'arix:logo'       => 'nullable|string',
            'arix:fullLogo'   => 'required|in:true,false',
            'arix:logoHeight' => 'required|string',
            'arix:discord'    => 'nullable|numeric',
            'arix:support'    => 'nullable|string',
            'arix:status'     => 'nullable|string',
            'arix:billing'    => 'nullable|string',
        ];
    }
}

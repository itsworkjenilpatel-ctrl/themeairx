<?php

namespace Pterodactyl\Http\Requests\Admin\Arix;

use Pterodactyl\Http\Requests\Admin\AdminFormRequest;

class ArixMetaRequest extends AdminFormRequest
{
    public function rules(): array
    {
        return [
            'arix:meta_color'       => ['required', 'string', 'regex:/^#([a-f0-9]{6}|[a-f0-9]{3})$/i'],
            'arix:meta_title'       => 'required|string',
            'arix:meta_description' => 'required|string',
            // FIX: Was 'required|string|url' — '/arix/meta-tags.png' is a path not a URL
            'arix:meta_image'       => 'nullable|string',
            // FIX: Same — '/arix/Arix.png' is a path not a URL
            'arix:meta_favicon'     => 'nullable|string',
        ];
    }
}

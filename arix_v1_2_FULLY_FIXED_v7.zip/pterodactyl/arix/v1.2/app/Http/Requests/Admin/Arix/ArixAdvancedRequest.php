<?php

namespace Pterodactyl\Http\Requests\Admin\Arix;

use Pterodactyl\Http\Requests\Admin\AdminFormRequest;

class ArixAdvancedRequest extends AdminFormRequest
{
    public function rules(): array
    {
        return [
            'arix:profileType'       => 'required|string|in:gravatar,boring,avataaars,bottts,identicon,initials',
            'arix:modeToggler'       => 'required|in:true,false',
            'arix:langSwitch'        => 'required|in:true,false',
            'arix:ipFlag'            => 'required|in:true,false',
            'arix:lowResourcesAlert' => 'required|in:true,false',
            'arix:font'              => 'nullable|string',
        ];
    }
}

<?php

namespace Pterodactyl\Http\Requests\Admin\Arix;

use Pterodactyl\Http\Requests\Admin\AdminFormRequest;

class ArixStylingRequest extends AdminFormRequest
{
    public function rules(): array
    {
        return [
            'arix:backgroundImage'      => 'nullable|string',
            'arix:backgroundImageLight' => 'nullable|string',
            'arix:backdrop'             => 'required|in:true,false',
            'arix:backdropPercentage'   => 'required|string',
            'arix:defaultMode'          => 'required|string',
            'arix:copyright'            => 'required|string',
            'arix:radiusInput'          => 'required|string',
            'arix:borderInput'          => 'required|in:true,false',
            'arix:radiusBox'            => 'required|string',
            'arix:flashMessage'         => 'required|numeric',
            // FIX: Was 'required|string' — but pageTitle is a boolean toggle, consistent with other booleans
            'arix:pageTitle'            => 'required|in:true,false',
            'arix:loginBackground'      => 'nullable|string',
            'arix:loginGradient'        => 'required|in:true,false',
        ];
    }
}

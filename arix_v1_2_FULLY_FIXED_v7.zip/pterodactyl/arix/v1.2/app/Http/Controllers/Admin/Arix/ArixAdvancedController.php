<?php

namespace Pterodactyl\Http\Controllers\Admin\Arix;

use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Http\Requests\Admin\Arix\ArixAdvancedRequest;
use Pterodactyl\Contracts\Repository\SettingsRepositoryInterface;

class ArixAdvancedController extends Controller
{
    public function __construct(private SettingsRepositoryInterface $settings) {}

    public function index(): View
    {
        return view('admin.arix.advanced', [
            'profileType'       => $this->settings->get('settings::arix:profileType', 'gravatar'),
            'modeToggler'       => $this->settings->get('settings::arix:modeToggler', 'true'),
            'langSwitch'        => $this->settings->get('settings::arix:langSwitch', 'true'),
            'ipFlag'            => $this->settings->get('settings::arix:ipFlag', 'true'),
            'lowResourcesAlert' => $this->settings->get('settings::arix:lowResourcesAlert', 'false'),
            'font'              => $this->settings->get('settings::arix:font', 'Roboto'),
        ]);
    }

    public function store(ArixAdvancedRequest $request): RedirectResponse
    {
        foreach ($request->validated() as $key => $value) {
            $this->settings->set('settings::' . $key, $value ?? '');
        }
        return redirect()->route('admin.arix.advanced')->with('success', 'Settings saved successfully.');
    }
}

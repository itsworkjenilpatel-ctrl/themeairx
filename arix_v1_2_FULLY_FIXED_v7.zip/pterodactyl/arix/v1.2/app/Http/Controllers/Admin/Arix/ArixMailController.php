<?php

namespace Pterodactyl\Http\Controllers\Admin\Arix;

use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Http\Requests\Admin\Arix\ArixMailRequest;
use Pterodactyl\Contracts\Repository\SettingsRepositoryInterface;

class ArixMailController extends Controller
{
    public function __construct(private SettingsRepositoryInterface $settings) {}

    public function index(): View
    {
        return view('admin.arix.mail', [
            'mail_color'           => $this->settings->get('settings::arix:mail_color', '#4a35cf'),
            'mail_backgroundColor' => $this->settings->get('settings::arix:mail_backgroundColor', '#F5F5FF'),
            'mail_logo'            => $this->settings->get('settings::arix:mail_logo', ''),
            'mail_logoFull'        => $this->settings->get('settings::arix:mail_logoFull', false),
            'mail_mode'            => $this->settings->get('settings::arix:mail_mode', 'light'),
            'mail_discord'         => $this->settings->get('settings::arix:mail_discord', ''),
            'mail_twitter'         => $this->settings->get('settings::arix:mail_twitter', ''),
            'mail_facebook'        => $this->settings->get('settings::arix:mail_facebook', ''),
            'mail_instagram'       => $this->settings->get('settings::arix:mail_instagram', ''),
            'mail_linkedin'        => $this->settings->get('settings::arix:mail_linkedin', ''),
            'mail_youtube'         => $this->settings->get('settings::arix:mail_youtube', ''),
            'mail_status'          => $this->settings->get('settings::arix:mail_status', ''),
            'mail_billing'         => $this->settings->get('settings::arix:mail_billing', ''),
            'mail_support'         => $this->settings->get('settings::arix:mail_support', ''),
        ]);
    }

    public function store(ArixMailRequest $request): RedirectResponse
    {
        foreach ($request->validated() as $key => $value) {
            $this->settings->set('settings::' . $key, $value ?? '');
        }
        return redirect()->route('admin.arix.mail')->with('success', 'Settings saved successfully.');
    }
}

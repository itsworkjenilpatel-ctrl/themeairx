<?php

namespace Pterodactyl\Http\Controllers\Admin\Arix;

use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Http\Requests\Admin\Arix\ArixAnnouncementRequest;
use Pterodactyl\Contracts\Repository\SettingsRepositoryInterface;

class ArixAnnouncementController extends Controller
{
    public function __construct(private SettingsRepositoryInterface $settings) {}

    public function index(): View
    {
        return view('admin.arix.announcement', [
            'announcementType'      => $this->settings->get('settings::arix:announcementType', 'party'),
            'announcementMessage'   => $this->settings->get('settings::arix:announcementMessage', ''),
            'announcementCloseable' => $this->settings->get('settings::arix:announcementCloseable', false),
        ]);
    }

    public function store(ArixAnnouncementRequest $request): RedirectResponse
    {
        foreach ($request->validated() as $key => $value) {
            $this->settings->set('settings::' . $key, $value ?? '');
        }
        return redirect()->route('admin.arix.announcement')->with('success', 'Settings saved successfully.');
    }
}

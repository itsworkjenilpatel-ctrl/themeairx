<?php

namespace Pterodactyl\Http\Controllers\Admin\Arix;

use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Http\Requests\Admin\Arix\ArixLayoutRequest;
use Pterodactyl\Contracts\Repository\SettingsRepositoryInterface;

class ArixLayoutController extends Controller
{
    public function __construct(private SettingsRepositoryInterface $settings) {}

    public function index(): View
    {
        return view('admin.arix.layout', [
            'layout'          => $this->settings->get('settings::arix:layout', 1),
            'searchComponent' => $this->settings->get('settings::arix:searchComponent', 1),
            'logoPosition'    => $this->settings->get('settings::arix:logoPosition', 1),
            'socialPosition'  => $this->settings->get('settings::arix:socialPosition', 1),
            'loginLayout'     => $this->settings->get('settings::arix:loginLayout', 1),
        ]);
    }

    public function store(ArixLayoutRequest $request): RedirectResponse
    {
        foreach ($request->validated() as $key => $value) {
            $this->settings->set('settings::' . $key, $value ?? '');
        }
        return redirect()->route('admin.arix.layout')->with('success', 'Settings saved successfully.');
    }
}

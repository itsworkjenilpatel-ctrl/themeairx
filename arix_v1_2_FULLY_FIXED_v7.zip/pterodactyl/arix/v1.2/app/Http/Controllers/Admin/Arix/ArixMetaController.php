<?php

namespace Pterodactyl\Http\Controllers\Admin\Arix;

use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Http\Requests\Admin\Arix\ArixMetaRequest;
use Pterodactyl\Contracts\Repository\SettingsRepositoryInterface;

class ArixMetaController extends Controller
{
    public function __construct(private SettingsRepositoryInterface $settings) {}

    public function index(): View
    {
        return view('admin.arix.meta', [
            'meta_color'       => $this->settings->get('settings::arix:meta_color', '#4a35cf'),
            'meta_title'       => $this->settings->get('settings::arix:meta_title', 'Pterodactyl Panel'),
            'meta_description' => $this->settings->get('settings::arix:meta_description', 'Our official Pterodactyl panel'),
            'meta_image'       => $this->settings->get('settings::arix:meta_image', '/arix/meta-tags.png'),
            'meta_favicon'     => $this->settings->get('settings::arix:meta_favicon', '/arix/Arix.png'),
        ]);
    }

    public function store(ArixMetaRequest $request): RedirectResponse
    {
        foreach ($request->validated() as $key => $value) {
            $this->settings->set('settings::' . $key, $value ?? '');
        }
        return redirect()->route('admin.arix.meta')->with('success', 'Settings saved successfully.');
    }
}

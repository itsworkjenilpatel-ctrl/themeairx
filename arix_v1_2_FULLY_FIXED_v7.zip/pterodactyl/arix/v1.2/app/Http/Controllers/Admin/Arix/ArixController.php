<?php

namespace Pterodactyl\Http\Controllers\Admin\Arix;

use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Http\Requests\Admin\Arix\ArixRequest;
use Pterodactyl\Contracts\Repository\SettingsRepositoryInterface;

class ArixController extends Controller
{
    public function __construct(private SettingsRepositoryInterface $settings) {}

    public function index(): View
    {
        return view('admin.arix.index', [
            'logo'       => $this->settings->get('settings::arix:logo', '/arix/Arix.png'),
            'fullLogo'   => $this->settings->get('settings::arix:fullLogo', false),
            'logoHeight' => $this->settings->get('settings::arix:logoHeight', '32px'),
            'discord'    => $this->settings->get('settings::arix:discord', ''),
            'support'    => $this->settings->get('settings::arix:support', ''),
            'status'     => $this->settings->get('settings::arix:status', ''),
            'billing'    => $this->settings->get('settings::arix:billing', ''),
        ]);
    }

    public function store(ArixRequest $request): RedirectResponse
    {
        foreach ($request->validated() as $key => $value) {
            $this->settings->set('settings::' . $key, $value ?? '');
        }
        return redirect()->route('admin.arix')->with('success', 'Settings saved successfully.');
    }
}

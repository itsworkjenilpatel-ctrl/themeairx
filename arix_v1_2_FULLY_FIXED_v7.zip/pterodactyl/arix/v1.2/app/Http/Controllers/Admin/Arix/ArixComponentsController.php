<?php

namespace Pterodactyl\Http\Controllers\Admin\Arix;

use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Http\Requests\Admin\Arix\ArixComponentsRequest;
use Pterodactyl\Contracts\Repository\SettingsRepositoryInterface;

class ArixComponentsController extends Controller
{
    public function __construct(private SettingsRepositoryInterface $settings) {}

    public function index(): View
    {
        return view('admin.arix.components', [
            'serverRow'     => $this->settings->get('settings::arix:serverRow', 1),
            'socialButtons' => $this->settings->get('settings::arix:socialButtons', false),
            'discordBox'    => $this->settings->get('settings::arix:discordBox', true),
            'statsCards'    => $this->settings->get('settings::arix:statsCards', 1),
            'sideGraphs'    => $this->settings->get('settings::arix:sideGraphs', 2),
            'graphs'        => $this->settings->get('settings::arix:graphs', 2),
            'slot1'         => $this->settings->get('settings::arix:slot1', 'disabled'),
            'slot2'         => $this->settings->get('settings::arix:slot2', 'disabled'),
            'slot3'         => $this->settings->get('settings::arix:slot3', 'disabled'),
            'slot4'         => $this->settings->get('settings::arix:slot4', 'disabled'),
            'slot5'         => $this->settings->get('settings::arix:slot5', 'disabled'),
            'slot6'         => $this->settings->get('settings::arix:slot6', 'disabled'),
            'slot7'         => $this->settings->get('settings::arix:slot7', 'disabled'),
        ]);
    }

    public function store(ArixComponentsRequest $request): RedirectResponse
    {
        foreach ($request->validated() as $key => $value) {
            $this->settings->set('settings::' . $key, $value ?? '');
        }
        return redirect()->route('admin.arix.components')->with('success', 'Settings saved successfully.');
    }
}

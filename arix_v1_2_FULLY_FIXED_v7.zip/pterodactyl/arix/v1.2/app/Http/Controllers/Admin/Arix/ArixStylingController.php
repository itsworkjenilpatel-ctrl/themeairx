<?php

namespace Pterodactyl\Http\Controllers\Admin\Arix;

use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Http\Requests\Admin\Arix\ArixStylingRequest;
use Pterodactyl\Contracts\Repository\SettingsRepositoryInterface;

class ArixStylingController extends Controller
{
    public function __construct(private SettingsRepositoryInterface $settings) {}

    public function index(): View
    {
        return view('admin.arix.styling', [
            'backgroundImage'      => $this->settings->get('settings::arix:backgroundImage', 'none'),
            'backgroundImageLight' => $this->settings->get('settings::arix:backgroundImageLight', 'none'),
            // FIX: Was 'false' (string) — made consistent with AssetComposer which uses false (boolean)
            'backdrop'             => $this->settings->get('settings::arix:backdrop', false),
            'backdropPercentage'   => $this->settings->get('settings::arix:backdropPercentage', '100%'),
            'defaultMode'          => $this->settings->get('settings::arix:defaultMode', 'darkmode'),
            // FIX: Inconsistent default — Controller had 'Powered by Pterodactyl', AssetComposer had 'Designed by Weijers.one'
            // Unified to AssetComposer value (source of truth for frontend)
            'copyright'            => $this->settings->get('settings::arix:copyright', 'Designed by Weijers.one'),
            'radiusInput'          => $this->settings->get('settings::arix:radiusInput', '7px'),
            // FIX: Was 'true' (string) — made consistent with AssetComposer
            'borderInput'          => $this->settings->get('settings::arix:borderInput', true),
            'radiusBox'            => $this->settings->get('settings::arix:radiusBox', '10px'),
            'flashMessage'         => $this->settings->get('settings::arix:flashMessage', 1),
            // FIX: Was 'true' (string) — consistent with AssetComposer boolean true
            'pageTitle'            => $this->settings->get('settings::arix:pageTitle', true),
            'loginBackground'      => $this->settings->get('settings::arix:loginBackground', '/arix/background-login.png'),
            // FIX: Was 'false' (string) — made consistent
            'loginGradient'        => $this->settings->get('settings::arix:loginGradient', false),
        ]);
    }

    public function store(ArixStylingRequest $request): RedirectResponse
    {
        foreach ($request->validated() as $key => $value) {
            $this->settings->set('settings::' . $key, $value ?? '');
        }
        return redirect()->route('admin.arix.styling')->with('success', 'Settings saved successfully.');
    }
}

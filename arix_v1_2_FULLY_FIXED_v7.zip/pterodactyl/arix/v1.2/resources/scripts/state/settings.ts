import { action, Action } from 'easy-peasy';

export interface SiteSettings {
    name: string;
    locale: string;
    arix: {
        logo: string;
        fullLogo: boolean;
        logoHeight: string;

        announcementType: string;
        announcementCloseable: boolean;
        announcementMessage: string;

        /* SOCIALS */
        discord: string;
        support: string;
        status: string;
        billing: string;

        /* COMPONENTS */
        serverRow: number;
        socialButtons: boolean;
        discordBox: boolean;

        statsCards: number;
        sideGraphs: number;
        graphs: number;

        slot1: string;
        slot2: string;
        slot3: string;
        slot4: string;
        slot5: string;
        slot6: string;
        slot7: string;

        /* LAYOUT */
        layout: number;
        searchComponent: number;
        logoPosition: number;
        socialPosition: number;
        loginLayout: number;

        /* STYLING */
        backgroundImage: string;
        // FIX: Was missing from interface
        backgroundImageLight: string;
        backdrop: boolean;
        backdropPercentage: string;
        defaultMode: string;
        modeToggler: boolean;
        langSwitch: boolean;
        copyright: string;
        radiusInput: string;
        borderInput: boolean;
        radiusBox: string;
        flashMessage: number;
        pageTitle: boolean;
        loginBackground: string;
        loginGradient: boolean;

        profileType: string;
        ipFlag: boolean;
        lowResourcesAlert: boolean;

        /* ADVANCED */
        // FIX: Was missing from interface
        font: string;

        /* COLORS - darkmode */
        primary: string;
        // FIX: All color fields below were missing from interface
        successText: string;
        successBorder: string;
        successBackground: string;
        dangerText: string;
        dangerBorder: string;
        dangerBackground: string;
        secondaryText: string;
        secondaryBorder: string;
        secondaryBackground: string;
        gray50: string;
        gray100: string;
        gray200: string;
        gray300: string;
        gray400: string;
        gray500: string;
        gray600: string;
        gray700: string;
        gray800: string;
        gray900: string;

        /* COLORS - lightmode */
        lightmode_primary: string;
        lightmode_successText: string;
        lightmode_successBorder: string;
        lightmode_successBackground: string;
        lightmode_dangerText: string;
        lightmode_dangerBorder: string;
        lightmode_dangerBackground: string;
        lightmode_secondaryText: string;
        lightmode_secondaryBorder: string;
        lightmode_secondaryBackground: string;
        lightmode_gray50: string;
        lightmode_gray100: string;
        lightmode_gray200: string;
        lightmode_gray300: string;
        lightmode_gray400: string;
        lightmode_gray500: string;
        lightmode_gray600: string;
        lightmode_gray700: string;
        lightmode_gray800: string;
        lightmode_gray900: string;

        /* MAIL - not used in frontend state but kept for completeness */
        mail_color: string;
        mail_backgroundColor: string;
        mail_logo: string;
        mail_logoFull: boolean;
        mail_mode: string;
        mail_discord: string;
        mail_twitter: string;
        mail_facebook: string;
        mail_instagram: string;
        mail_linkedin: string;
        mail_youtube: string;
        mail_status: string;
        mail_billing: string;
        mail_support: string;

        /* META */
        meta_color: string;
        meta_title: string;
        meta_description: string;
        meta_image: string;
        meta_favicon: string;
    };
    recaptcha: {
        enabled: boolean;
        siteKey: string;
    };
}

export interface SettingsStore {
    data?: SiteSettings;
    setSettings: Action<SettingsStore, SiteSettings>;
}

const settings: SettingsStore = {
    data: undefined,

    setSettings: action((state, payload) => {
        state.data = payload;
    }),
};

export default settings;

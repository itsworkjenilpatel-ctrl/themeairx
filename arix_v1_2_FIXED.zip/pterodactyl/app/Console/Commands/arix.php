<?php

namespace Pterodactyl\Console\Commands;

use Illuminate\Console\Command;
use Symfony\Component\Console\Formatter\OutputFormatterStyle;
use Illuminate\Support\Facades\File;

class Arix extends Command
{
    protected $signature = 'arix {action?}';
    protected $description = 'All commands for Arix Theme for Pterodactyl.';

    protected $supportedVersions = [
        '1.11.7', '1.11.6', '1.11.5', '1.11.4', '1.11.3', '1.11.2', '1.11.1', '1.11.0',
        '1.10.4', '1.10.3', '1.10.2', '1.10.1', '1.10.0',
        '1.9.2',  '1.9.1',  '1.9.0',
        '1.8.1',  '1.8.0',
        '1.7.0',
        '1.6.6',  '1.6.5',  '1.6.4',  '1.6.3',  '1.6.2',  '1.6.1',  '1.6.0',
    ];

    public function handle()
    {
        $action = $this->argument('action');

        $title = new OutputFormatterStyle('#fff', null, ['bold']);
        $this->output->getFormatter()->setStyle('title', $title);

        $b = new OutputFormatterStyle(null, null, ['bold']);
        $this->output->getFormatter()->setStyle('b', $b);

        if ($action === null) {
            $this->line("
            <title>
            ░█████╗░██████╗░██╗██╗░░██╗
            ██╔══██╗██╔══██╗██║╚██╗██╔╝
            ███████║██████╔╝██║░╚███╔╝░
            ██╔══██║██╔══██╗██║░██╔██╗░
            ██║░░██║██║░░██║██║██╔╝╚██╗
            ╚═╝░░╚═╝╚═╝░░╚═╝╚═╝╚═╝░░╚═╝

           Thank you for using Arix</title>

           > php artisan arix (this window)
           > php artisan arix install
           > php artisan arix update
           > php artisan arix uninstall
            ");
        } elseif ($action === 'install') {
            $this->install();
        } elseif ($action === 'update') {
            $this->update();
        } elseif ($action === 'uninstall') {
            $this->uninstall();
        } else {
            $this->error("Invalid action. Supported actions: install, update, uninstall");
        }
    }

    public function installOrUpdate($isUpdate = false)
    {
        if ($isUpdate) {
            $this->info("This command skips frequently used files by addons during theme updating to avoid losing your addon customizations. If you still experience an error after updating please contact us.");
        }

        $panelVersion = config('app.version');
        if (in_array($panelVersion, $this->supportedVersions)) {
            $this->info("✓ Pterodactyl version {$panelVersion} — Supported.");
        } else {
            $this->warn("⚠  Pterodactyl version {$panelVersion} is not in the tested list.");
            $this->warn("   Arix is tested on: " . implode(', ', $this->supportedVersions));
            $this->warn("   Proceeding anyway — some features may not work correctly.");
            $proceed = $this->confirm("Do you want to continue installation?", true);
            if (!$proceed) {
                return;
            }
        }

        $confirmation = $this->confirm("Are all the required dependencies installed from the readme file?", 'yes');
        if (!$confirmation) {
            return;
        }

        $versions = File::directories('./arix');
        if (empty($versions)) {
            $this->info('No versions found in /arix directory.');
            return;
        }

        $rawVersion = basename($this->choice('Select a version:', $versions));
        $version = preg_replace('/[^a-zA-Z0-9._-]/', '', $rawVersion);
        if (empty($version)) {
            return $this->error("Invalid version selected.");
        }

        $this->info("Installing Arix Theme $version...");

        if ($isUpdate) {
            $excludeOption = "--exclude='routes.ts' --exclude='getServer.ts' --exclude='admin.blade.php' --exclude='admin.php' --exclude='ServerTransformer.php'";
        } else {
            $excludeOption = '';
        }

        $this->runCommand("rsync -a $excludeOption arix/" . escapeshellarg($version) . "/ ./");

        $directoryPath = app_path('Http/Controllers/Admin/Arix');
        File::makeDirectory($directoryPath, 0755, true, true);

        $this->info('Proceeding with the installation...');
        $this->info('Migrating database...');
        $this->runCommand('php artisan migrate --force');

        $this->info('Installing required packages...');
        $this->info('This can take a minute...');
        $this->runCommand('yarn add @types/md5 md5 react-icons @types/bbcode-to-react bbcode-to-react i18next-browser-languagedetector@7.2.1');

        $this->info('Building panel assets...');

        $nodeVersion = shell_exec('node -v 2>/dev/null');
        $nodeVersion = (int) ltrim(trim((string)$nodeVersion), 'v');

        if ($nodeVersion >= 17) {
            $this->info('Node.js version is v' . $nodeVersion . ' (>= 17)');
            putenv('NODE_OPTIONS=--openssl-legacy-provider');
        } else {
            $this->info('Node.js version is v' . $nodeVersion . ' (< 17)');
        }

        $this->runCommand('yarn build:production');

        $this->info('Set permissions...');
        $basePath = escapeshellarg(base_path());
        $this->runCommand('chown -R www-data:www-data ' . $basePath . '/*');
        $this->runCommand('chown -R nginx:nginx ' . $basePath . '/*');
        $this->runCommand('chown -R apache:apache ' . $basePath . '/*');

        $this->info('Optimize application...');
        $this->runCommand('php artisan optimize:clear');
        $this->runCommand('php artisan optimize');

        $message = $isUpdate ? '✓    Theme updated    ✓' : '✓    Theme installed    ✓';
        $this->line("
        ╭───────────────────────────────╮
        │                               │
        $message
        │    ╰─╴   successfully   ╶─╯   │
        │                               │
        ╰───────────────────────────────╯
    ");
    }

    public function install()
    {
        $this->installOrUpdate();
    }

    public function update()
    {
        $this->installOrUpdate(true);
    }

    private function uninstall()
    {
        // FIX: Added confirmation prompt — uninstall is destructive (wipes panel files)
        $this->warn("⚠  WARNING: This will UNINSTALL Arix and restore the default Pterodactyl panel.");
        $this->warn("   All Arix customizations will be lost.");
        $confirm = $this->confirm("Are you sure you want to uninstall Arix?", false);
        if (!$confirm) {
            $this->info("Uninstall cancelled.");
            return;
        }

        $this->line("Uninstalling...");
        $this->runCommand('php artisan down');
        $this->runCommand('curl -fsSL https://github.com/pterodactyl/panel/releases/latest/download/panel.tar.gz | tar -xzv');
        $this->runCommand('chmod -R 755 storage/* bootstrap/cache');
        $this->runCommand('composer install --no-dev --optimize-autoloader');
        $this->runCommand('php artisan view:clear');
        $this->runCommand('php artisan config:clear');
        $this->runCommand('php artisan migrate --seed --force');

        $basePath = escapeshellarg(base_path());
        $this->runCommand('chown -R www-data:www-data ' . $basePath . '/*');
        $this->runCommand('chown -R nginx:nginx ' . $basePath . '/*');
        $this->runCommand('chown -R apache:apache ' . $basePath . '/*');
        $this->runCommand('php artisan queue:restart');
        $this->runCommand('php artisan up');

        $this->info("✓ Arix uninstalled successfully.");
    }

    // FIX: runCommand now uses passthru() instead of exec() so full output is shown
    // exec() only returns the LAST line — build errors, migration errors were invisible
    private function runCommand($cmd)
    {
        passthru($cmd);
    }
}
